#include<SDL/SDL.h>
#include<GL/gl.h>
#include<GL/glu.h>
//============================
//=====================================================
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
using namespace std;


//===============================
void init()
{
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-20,20,-20,20);
}
//===============================

void Draw_line_2d(float px,float py,float qx,float qy)
{

glBegin(GL_LINES);
    glVertex2f(px,py);
    glVertex2f(qx,qy);
glEnd();
}


void display()
{
//------
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glPushMatrix();


glLineWidth(5);


// Axes
glColor3f( 0.0, 0.0, 0.0);
Draw_line_2d(-20,0,20,-0);
glBegin(GL_TRIANGLES);
    glVertex2f(0.0,20.0);
    glVertex2f(-0.5,19);
    glVertex2f(0.5,19);
glEnd();

Draw_line_2d(0,-20,0,20);
glBegin(GL_TRIANGLES);
    glVertex2f(20.0,0.0);
    glVertex2f(19, 0.5);
    glVertex2f(19,-0.5);
glEnd();

glLineWidth(2);

glColor3f( 1.0, 0.0, 0.0);

glBegin(GL_LINE_STRIP);
    glVertex2f(-20,-1);
    glVertex2f(11.5,20);
glEnd();

glColor3f( 0.0, 1.0, 0.0);

glBegin(GL_LINE_STRIP);
    glVertex2f(-20,7);
    glVertex2f(20,7);
glEnd();

glPopMatrix();

}



int main(int argc, char* args[])
{
    SDL_Init(SDL_INIT_EVERYTHING);

    SDL_SetVideoMode(600,400,32,SDL_SWSURFACE|SDL_OPENGL);

    int petla=1;

    SDL_Event zdarzenie;
    init();
    while (petla==1)
    {

        while (SDL_PollEvent(&zdarzenie))
        {
            switch(zdarzenie.type)
            {
                case SDL_QUIT:
                petla=0;
                break;
            }
        }
       display();

        SDL_GL_SwapBuffers();

    }
    SDL_Quit();
    return 0;
}
