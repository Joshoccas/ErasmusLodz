
#include<SDL/SDL.h>
#include<GL/gl.h>
#include<GL/glu.h>
//============================
//=====================================================
#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h> // system
using namespace std;


//===============================
void init()
{
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-8,8,-8,8);
}
//===============================


//===============================
void Draw_point_2d(float px,float py)
{
glBegin(GL_POINTS);
    glVertex2f(px,py);
glEnd();
}
//===============================



void display()
{
//------
glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
glPushMatrix();

glLineWidth(20);
glColor3f( 0.0, 0.0, 1.0);
glBegin(GL_QUADS);
    glVertex2f(-1,-1);
    glVertex2f(5,-1);
    glVertex2f(5,4);
    glVertex2f(-1,4);
glEnd();

glColor3f( 1.0, 1.0, 1.0);
glBegin(GL_QUADS);
    glVertex2f(0,-1);
    glVertex2f(0,1);
    glVertex2f(2,1);
    glVertex2f(2,-1);
glEnd();

glColor3f( 1.0, 1.0, 1.0);
glBegin(GL_QUADS);
    glVertex2f(2,2);
    glVertex2f(4,2);
    glVertex2f(4,3);
    glVertex2f(2,3);
glEnd();

glColor3f( 1.0, 0.0, 0.0);
glBegin(GL_TRIANGLES);
    glVertex2f(-1,4);
    glVertex2f(2,7);
    glVertex2f(5,4);
glEnd();

glPopMatrix();

}



int main(int argc, char* args[])
{
    SDL_Init(SDL_INIT_EVERYTHING);

    SDL_SetVideoMode(600,400,32,SDL_SWSURFACE|SDL_OPENGL);

    int petla=1;

    SDL_Event zdarzenie;
    init();
    while (petla==1)
    {

        while (SDL_PollEvent(&zdarzenie))
        {
            switch(zdarzenie.type)
            {
                case SDL_QUIT:
                petla=0;
                break;
            }
        }
       display();

        SDL_GL_SwapBuffers();

    }
    SDL_Quit();
    return 0;
}
